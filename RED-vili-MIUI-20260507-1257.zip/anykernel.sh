### AnyKernel3 Ramdisk Mod Script
## osm0sis @ xda-developers

### AnyKernel setup
# global properties
properties() { '
kernel.string=RED kernel by kknixx
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=Xiaomi 11T Pro
device.name2=milahaina
device.name3=vili
supported.versions=11.0-16.0
supported.patchlevels=
supported.vendorpatchlevels=
'; } # end properties

### AnyKernel install
## boot shell variables
BLOCK=boot;
IS_SLOT_DEVICE=1;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

# import functions/variables and setup patching - see for reference (DO NOT REMOVE)
. tools/ak3-core.sh && passthrough;

# boot install — MIUI/HyperOS: replace kernel in boot partition.
dump_boot;

write_boot;
## end boot install

## vendor_boot — flash our DTB + empty modules.load (fix slow boot)
BLOCK=vendor_boot;
IS_SLOT_DEVICE=1;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

reset_ak;

split_boot;
unpack_ramdisk;

# Empty modules.load — all drivers are built-in to our kernel.
# Stock modules.load has .ko files with wrong vermagic (5.4.274 vs
# our 5.4.302). Each failed load attempt times out, causing 2-3 min
# delay at MI logo before boot animation starts.
# Clear both paths — init checks lib/modules/modules.load AND
# lib/modules/5.4-gki/modules.load
find $AKHOME/ramdisk/lib/modules -name "modules.load" -exec sh -c 'echo -n > {}' \;
find $AKHOME/ramdisk/lib/modules -name "modules.dep" -exec sh -c 'echo -n > {}' \;

repack_ramdisk;
flash_boot;
## end vendor_boot install
